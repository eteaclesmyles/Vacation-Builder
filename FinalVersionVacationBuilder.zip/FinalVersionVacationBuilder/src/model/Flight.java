package model;

/**
 * Model class Flight.
 * @author Maria Jose Healey(spb340)
 * @version 1.0
 */
public class Flight {
	private String depDate;
	private String retDate;
	private String airline;
	
	/* constructor */
	public Flight(String depDate, String retDate, String airline) { 
		this.depDate = depDate;
		this.retDate = retDate;
		this.airline = airline;
	}

	/* getters and setters */
	public String getDepDate() {
		return depDate;
	}

	public void setDepDate(String depDate) {
		this.depDate = depDate;
	}

	public String getRetDate() {
		return retDate;
	}

	public void setRetDate(String retDate) {
		this.retDate = retDate;
	}

	public String getAirline() {
		return airline;
	}

	public void setAirline(String airline) {
		this.airline = airline;
	}

}
