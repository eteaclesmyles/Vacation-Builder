package controller;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.stage.Stage;
import model.City;
import model.Flight;

/**
 * Controller class for Scene5.fxml (City).
 * Provides the vacation summary. 
 * @author Maria Jose Healey(spb340)
 * @version 1.0
 */

public class Scene5Controller {
	private City vacation;
	private Flight flight;
	
	/* Buttons */
    @FXML
    private Button mainMenuB;
    @FXML
    private Button closeB;
    @FXML
    private Button summaryB;
    
    /* Label */
    @FXML
    private Label summaryLabel;
    
    /* Text Area */
    @FXML
    private TextArea summaryTA;
    
    /* Handles the close Button */
	@FXML
	public void handleCloseB(ActionEvent event) throws IOException {
		Platform.exit();
	}	
	
	/* Handles the mainMenuB Button */
	@FXML
	public void handleMainMenuB(ActionEvent event) throws IOException {
		Parent scene4 = FXMLLoader.load(getClass().getResource("/view/Menu.fxml"));
		Scene scene4Scene = new Scene(scene4);
		Stage scene4Window = (Stage) ((Node) event.getSource()).getScene().getWindow();
		scene4Window.setScene(scene4Scene);
		scene4Window.show();
	}

	/* handles handleSummaryB */
	@FXML
	public void handleSummaryB(ActionEvent event) throws IOException {
		String summary;
		double totalCost;
		String newDeparture,newReturn;
	
		newDeparture=vacation.getFlight().getDepDate().substring(5) +"-" + vacation.getFlight().getDepDate().substring(0,4);
		newReturn= vacation.getFlight().getRetDate().substring(5) + "-" + vacation.getFlight().getRetDate().substring(0,4);
		totalCost= (vacation.getDays()*getCost(vacation.getHotel()))+getCost(vacation.getFlight().getAirline());
		summaryTA.setVisible(true);
		summary= "Trip Duration: " + vacation.getDays() + " day(s)\n" +
				 "Departure Date: " +newDeparture + "\n"+
				 "Return Date: " + newReturn + "\n"+
				 "Destination City: " + vacation.getCityName() +"\n"+
		         "Hotel: " +vacation.getHotel() + " per night\n" + 
				 "Flight: " +vacation.getFlight().getAirline() + " round trip\n" +
		         "Activities: ";
		if (vacation.getActividades().isEmpty()==true){
			summary+="None\n";
		}else{
			summary+="\n";
			for(String arrayListItems:vacation.getActividades()){
				summary+=arrayListItems+"\n";
				totalCost+=getCost(arrayListItems);
			}
		}
		summaryTA.setText(summary + "Total cost of Vacation: $" + new DecimalFormat("#.##").format(totalCost));
		
	}
		
	/* method to obtain city,hotel,flight,activities,days,departure and return dates from Scene4Controller */
    public void transferMessage(String userCity, String userHotel, String userFlight, ArrayList<String> userActivities,String userDepartureDate,String userReturnDate,int userVacationDays){
    	flight=new Flight(userDepartureDate,userReturnDate,userFlight);
    	vacation= new City(userCity,flight,userHotel,userActivities,userVacationDays);
    }
    
    /* method to obtain the cost($) from a string */
    public double getCost(String sentence){
        double cost;
        String amount;
    	String delimeter;
    	String[] tokens;
    	
    	delimeter="[,]";
    	tokens = sentence.split(delimeter);
    	amount=tokens[1];  
    	cost= Double.parseDouble(amount.substring(1));
    	return cost ;
    }

}
