package controller;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.layout.AnchorPane;
import javafx.scene.control.ComboBox;
import javafx.stage.Stage;

/**
 * Controller class for Scene2.fxml (City).
 * It allows users to pick both a city destination and hotel. 
 * @author Maria Jose Healey(spb340)
 * @version 1.0
 */

public class Scene2Controller implements Initializable {
	private String destinationCity="";
	private String hotel="";
	
	@FXML
	private AnchorPane cityScene2AP;
	
	/* Buttons */
    @FXML
    private Button Prev;
    @FXML
    private Button Next;
    
    /* Labels */
    @FXML
    private Label destinationLabel;
    @FXML
    private Label cityLabel;
    @FXML
    private Label hotelsLabel;
    
    /* ComboBoxes */
	@FXML
	private ComboBox destinationCB;
	private ObservableList<String> cities=FXCollections.observableArrayList("Las Vegas","Miami","New Orleans","New York","San Francisco");  
	@FXML
	private ComboBox hotelsCB;
	private ObservableList<String> hotels=FXCollections.observableArrayList("");
   
	/* handles the next Button */
	@FXML
	public void nextButtonPressed(ActionEvent event) throws IOException {
		if (destinationCity.equals("") || hotel.equals("")){
			Alert error= new Alert(AlertType.ERROR);
			error.setTitle("Error Message");
			error.setHeaderText("Missing destination city and/or hotel");
			error.setContentText("Please,pick destination city and then hotel");
			error.showAndWait();
	
		}else{
			/* Communicating with scene3 */
			FXMLLoader loader=new FXMLLoader(getClass().getResource("/view/Scene3.fxml"));	
			cityScene2AP= (AnchorPane)loader.load();
			Scene3Controller scene3Controller= loader.getController();	    
			scene3Controller.transferMessage(destinationCity,hotel);	        
	        
			Scene scene = new Scene(cityScene2AP);// pane you are GOING TO show
			Stage window = (Stage) ((Node)event.getSource()).getScene().getWindow();// pane you are ON
			window.setScene(scene);
			window.show();
		}
	}
	
	/* Handles the previous Button */
	@FXML
	public void prevButtonPressed(ActionEvent event) throws IOException {
		Parent  scene2 = FXMLLoader.load(getClass().getResource("/view/Menu.fxml"));
		Scene scene2Scene = new Scene(scene2);
		Stage scene2Window = (Stage) ((Node) event.getSource()).getScene().getWindow();
		scene2Window.setScene(scene2Scene);
		scene2Window.show();
	}
	
	/* handles the destinationCB ComboBox */
	@FXML
	public void handleDestinationCB(ActionEvent event) throws IOException {		
		destinationCity=destinationCB.getValue().toString();;//global variable
		hotels.clear();
		switch(destinationCity)
	     {
	        case "Las Vegas":	        	
	        	hotels.addAll("Winn Las Vegas ,$113",
	        				  "The Venetian Las Vegas ,$138",
	        				  "The Palazzo Las Vegas ,$374",
	        				  "Belaggio Resort and Casino ,$993",
	        				  "Waldorf Astoria Las Vegas ,$191");
	        	break;
	        case "Miami":
	        	hotels.addAll("InterContinental Miami ,$248",
	        				  "East Miami ,$279",	        			
	        				  "W Miami ,$449",
	        				  "Miami Marriott Hotel Biscayne Bay ,$319",	        				 
	        				  "EB Hotel Miami Airport ,$175");	
	        	break;
	        case "New Orleans":
	        	hotels.addAll("Windsor Court Hotel ,$340",
	        				  "Le Pavillon Hotel ,$109",
	        				  "Melrose Mansion ,$135",
	        				  "Bourbon Orleans Hotel ,$175",
	        				  "Omni Riverfront Hotel ,$139");	
	        	break;
	        case "New York":
	        	hotels.addAll("The Plaza New York ,$600",
	        				  "Four Seasons Hotel New York ,$665",
	        				  "The St. Regis Hotel New York ,$806",
	        				  "The NoMad Hotel ,$355",
	        				  "1 Hotel Central Park ,$329");	  
	        	break;
	        case "San Francisco":
	        	hotels.addAll("The Stanford Court San Francisco ,$199",
	        				  "The Inn Above Tide ,$435",
	        				  "Fairmont San Francisco ,$229",
	        				  "The Ritz - Carlton San Francisco ,$439",
	        				  "Hotel Drisco ,$399");
	        	break;
	     }
		
	}
	
	/* handles the hotelsCB ComboBox */
	@FXML
	public void handleHotelsCB(ActionEvent event) throws IOException {
		hotel=hotelsCB.getValue().toString();
	}
	public void initialize(URL arg0, ResourceBundle arg1) {
		destinationCB.setItems(cities); // sets up ComboBox destinationCB
		hotelsCB.setItems(hotels);
		
	}
	
	/* getter and setter for ObservableList cities */
	public ObservableList<String> getCities() {
		return cities;
	}
	public void setCities(ObservableList<String> cities) {
		this.cities = cities;
	}

	/* getter and setter for ObservableList cities */
	public ObservableList<String> getHotels() {
		return hotels;	}

	public void setHotels(ObservableList<String> hotels) {
		this.hotels = hotels;
	}

}
