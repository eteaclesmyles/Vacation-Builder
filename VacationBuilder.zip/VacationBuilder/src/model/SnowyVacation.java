package model;

import java.util.HashMap;

public class SnowyVacation 
{
	public static String strDest;
	public static int iTravelerNum;
	public static double dDistanceFromSA;
	public static HashMap<String,Integer> hmActivities= new HashMap<>();
	
	public SnowyVacation()
	{
		strDest = null;
		iTravelerNum = 0;
		dDistanceFromSA = 0;
		
	}
	
	public static void setDest(String strDest)
	{
		SnowyVacation.strDest = strDest;
	}
	
	public static void setTravelNum(int iTravelNum)
	{
		SnowyVacation.iTravelerNum =iTravelNum;
	}
	
	public static void setDistance(double dDistance)
	{
		SnowyVacation.dDistanceFromSA = dDistance;
	}
}
