package model;

public class Transportation 
{
	public static String transportType;
	public static double dRate;
	
	
	
}
