package citymodel;

/**
 * Model class Flight.
 * @author Maria Jose Healey(spb340)
 * @version 1.0
 */
public class Flight {
	private String depDate;
	private String retDate;
	private String airline;
	private double price;
	
	/* constructor */
	public Flight(String depDate, String retDate, String airline, double price) {
		this.depDate = depDate;
		this.retDate = retDate;
		this.airline = airline;
		this.price = price;
	}

	/* getters and setters */
	public String getDepDate() {
		return depDate;
	}

	public void setDepDate(String depDate) {
		this.depDate = depDate;
	}

	public String getRetDate() {
		return retDate;
	}

	public void setRetDate(String retDate) {
		this.retDate = retDate;
	}

	public String getAirline() {
		return airline;
	}

	public void setAirline(String airline) {
		this.airline = airline;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}
	
	
	

}
