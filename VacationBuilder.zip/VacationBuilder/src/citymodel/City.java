package citymodel;

import java.util.HashMap;

/**
 * Model class City. 
 * @author Maria Jose Healey(spb340)
 * @version 1.0
 */

public class City {
	private String cityName;
	private HashMap<String, String> hotel=new HashMap<String,String>(); // name,price
	private Flight flight; // departure date, return date, airline,price
	private HashMap<String, String> actividades=new HashMap<String,String>(); // activity,price
	
	/* constructor */
	public City(String cityName,Flight flight, HashMap<String, String> hotel, HashMap<String, String> actividades) {
		this.cityName=cityName;
		this.flight = flight;
		this.hotel = hotel;
		this.actividades = actividades;
	}

	/* getters and setters */
	public String getCityName(){
		return cityName;
	}
	public void setCityName(String cityName){
		this.cityName=cityName;
	}
	public Flight getFlight() {
		return flight;
	}

	public void setFlight(Flight flight) {
		this.flight = flight;
	}

	public HashMap<String, String> getHotel() {
		return hotel;
	}

	public void setHotel(HashMap<String, String> hotel) {
		this.hotel = hotel;
	}

	public HashMap<String, String> getActividades() {
		return actividades;
	}

	public void setActividades(HashMap<String, String> actividades) {
		this.actividades = actividades;
	}
	
}
