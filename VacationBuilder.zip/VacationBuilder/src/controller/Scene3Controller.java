package controller;

import java.io.IOException;
import java.net.URL;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.util.Callback;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.layout.AnchorPane;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DateCell;
import javafx.scene.control.DatePicker;

/**
 * Controller class for Scene3.fxml (City).
 * It allows users to pick departure and return dates as well as flights. 
 * @author Maria Jose Healey(spb340)
 * @version 1.0
 */

public class Scene3Controller implements Initializable{	
	private String userDestinationChoice;
	private String userHotelChoice;
	private String flight="";
	int days;
	private String departureDate="";
	private String returnDate="";
	private String returningDate;
	
	@FXML
	private AnchorPane cityScene3AP;
	
	/* Buttons */
    @FXML
    private Button Prev;
    @FXML
    private Button Next;
    @FXML
    private Button searchFlightsB;
    
    /* Label */
    @FXML
    private Label flightsLabel;
    
    /* DatePickers */
    @FXML
    private DatePicker departureDP;
    @FXML
    private DatePicker returnDP;
    
    
    /* ComboBox */
	@FXML
	private ComboBox flightsCB;
	ObservableList<String> flights=FXCollections.observableArrayList("");
	
   
	/* handles the next Button */
	@FXML
	public void nextButtonPressed(ActionEvent event) throws IOException {
		if (flight.equals("")){
			Alert error= new Alert(AlertType.ERROR);
			error.setTitle("Error Message");
			error.setHeaderText("Missing Flight Information");
			error.setContentText("Please,pick a flight");
			error.showAndWait();
		}else{
			/* Communicating with scene3 */
			FXMLLoader loader=new FXMLLoader(getClass().getResource("/view/Scene4.fxml"));
			cityScene3AP= (AnchorPane)loader.load();
			Scene4Controller scene4Controller= loader.getController();
			scene4Controller.transferMessage(userDestinationChoice,userHotelChoice,flight,days,departureDate,returnDate);	        
	        
			Scene scene = new Scene(cityScene3AP);// pane you are GOING TO show
			Stage window = (Stage) ((Node)event.getSource()).getScene().getWindow();// pane you are ON
			window.setScene(scene);
			window.show();
		}
	}
	
	/* handles the previous Button */
	@FXML
	public void prevButtonPressed(ActionEvent event) throws IOException {
		Parent scene3 = FXMLLoader.load(getClass().getResource("/view/Scene2.fxml"));
		Scene scene3Scene = new Scene(scene3);
		Stage scene3Window = (Stage) ((Node) event.getSource()).getScene().getWindow();
		scene3Window.setScene(scene3Scene);
		scene3Window.show();
	}
	/* handles the flightsCB ComboBox */
	@FXML
	public void handleSearchFlightsB(ActionEvent event) throws IOException {
		if (departureDate.equals("") || returnDate.equals("")){
			Alert error= new Alert(AlertType.ERROR);
			error.setTitle("Error Message");
			error.setHeaderText("Missing Dates");
			error.setContentText("Please,pick a departure and return date");
			error.showAndWait();
		}else{		
			switch (userDestinationChoice){
				case "Las Vegas":
					flights.clear();
					flights.addAll("Alaska Airlines  (Non / 1 Stop) ,$292.82",
								   "American Airlines (Non / 1 Stop) ,$193.20",
								   "American Airlines (Non / 1 Stop) ,$184.52",
								   "United Airlines (Non / 1 Stop) ,$175.84",
			        		   	   "United Airlines (Non / 1 Stop) ,$184.52");
					break;
				case "Miami":
					flights.clear();
					flights.addAll("American Airlines (1+ Stop) ,$106.02",
			        		   	   "American Airlines (Non / 1 Stop) ,$112.20",
			        		   	   "American Airlines (Non / 1 Stop) ,$110.60",
			        		   	   "United Airlines (1+ Stop),$109",
			        		   	   "United Airlines (1+ Stop) ,$148.60");
					break;
				case "New Orleans":
					flights.clear();
					flights.addAll("Alaska Airlines (Non / 1 Stop) ,$461.02",
								   "American Airlines (Non / 1 Stop) ,$150.20",
								   "American Airlines (Non / 1 Stop) ,$141.52",
								   "United Airlines (Non / 1 Stop) ,$135.14",
			        		   	   "United Airlines (Non / 1 Stop) ,$141.52");
					break;
				case "New York":
					flights.clear();	        	
					flights.addAll("Alaska Airlines (Non / 1 Stop) ,$488.75",
			        		   	   "American Airlines (Non / 1 Stop) ,$250.30",
			        		   	   "American Airlines (Non / 1 Stop) ,$250.29",
			        		   	   "United Airlines (Non / 1 Stop) ,$265.78",
			        		   	   "United Airlines (Non / 1 Stop) ,$199.67");
					break;
				case "San Francisco":
					flights.clear();
					flights.addAll("Alaska Airlines (1+ Stop) ,$215.50",
			        		   	   "American Airlines (1+ Stop) ,$180.86",
			        		   	   "American Airlines (Non / 1 Stop) ,$185.02",
			        		   	   "United Airlines (Non / 1 Stop) ,$209.82",
			        		   	   "United Airlines (Non / 1 Stop) ,$185.02");
					break;			       
			}
		
			/*calculating number of days in between - Parsing the date */
			days = (int)ChronoUnit.DAYS.between(LocalDate.parse(departureDate), LocalDate.parse(returnDate));			
			//displaying the number of days
			//System.out.println(days);
		}
		
	}
	
	/* handles the flightsCB ComboBox */
	@FXML
	public void handleFlightsCB(ActionEvent event) throws IOException {
		flight=flightsCB.getValue().toString();
	}
	
	/* handles the departureDP DatePicker */
	@FXML
	public void handleDepartureDP(ActionEvent event) throws IOException {
		SimpleDateFormat dateFormat=new SimpleDateFormat("yyyy-MM-dd");
		if (departureDP.getValue()!= null)
			try {
				departureDate=dateFormat.format(dateFormat.parse(this.departureDP.getValue().toString()));
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		//System.out.println(departureDate);
	}
	
	/* handles the returnDP DatePicker */
	@FXML
	public void handleReturnDP(ActionEvent event) throws IOException {
		SimpleDateFormat dateFormat=new SimpleDateFormat("yyyy-MM-dd");
		//SimpleDateFormat dateFormat=new SimpleDateFormat("MM-dd-yyyy");
		if (returnDP.getValue()!= null)
			try {
				returnDate=dateFormat.format(dateFormat.parse(this.returnDP.getValue().toString()));
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		//System.out.println(returnDate);
	}
	
	public void initialize(URL arg0, ResourceBundle arg1) {
		
		flightsCB.setItems(flights); //sets up ComboBox flightsCB
		blockingDates();
		
	}
	/* getter and setter for ObservableList flights */
	public ObservableList<String> getFlights() {
		return flights;
	}

	public void setFlights(ObservableList<String> flights) {
		this.flights = flights;
	}	
	
	/* method to obtain the the value of variables destinationCity and hotel from Scene2Controller */
    public void transferMessage(String destinationCity, String hotel ){
    	userDestinationChoice=destinationCity;
    	userHotelChoice=hotel;
    }
    
    /* blocks dates not available*/
    public void blockingDates() {
		final Callback<DatePicker, DateCell> dayCellFactory = new Callback<DatePicker, DateCell>() {
			public DateCell call(final DatePicker datePicker) {
				return new DateCell() {
					public void updateItem(LocalDate item, boolean empty) {
						super.updateItem(item, empty);
						if (item.isBefore(LocalDate.now())) {
							setDisable(true);
							setStyle("-fx-background-color: lightblue;");
						}
					}
				};
			}
		};
		final Callback<DatePicker, DateCell> dayCellFactory1 = new Callback<DatePicker, DateCell>() {
			public DateCell call(final DatePicker datePicker) {
				return new DateCell() {
					public void updateItem(LocalDate item, boolean empty) {
						super.updateItem(item, empty);
						if (item.isBefore(departureDP.getValue().plusDays(1))) {
							setDisable(true);
							setStyle("-fx-background-color:aquamarine;");
						}
					}
				};
			}
		};

		departureDP.setDayCellFactory(dayCellFactory);
		departureDP.setValue(LocalDate.now());
		returnDP.setDayCellFactory(dayCellFactory1);
		returnDP.setValue(LocalDate.now().plusDays(3));

	}
    
}

