package controller;
import java.io.IOException;
import java.net.URL;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.stage.Stage;

/**
 * Controller class for Scene5.fxml (City).
 * Provides the vacation summary. 
 * @author Maria Jose Healey(spb340)
 * @version 1.0
 */

public class Scene5Controller {
	private String city;
	private String hotel;
	private String flight;
	private ArrayList<String> activities;
	private int days;
	private String departure;
	private String returning;
	
	/* Buttons */
    @FXML
    private Button mainMenuB;
    @FXML
    private Button closeB;
    @FXML
    private Button summaryB;
    
    /* Label */
    @FXML
    private Label summaryLabel;
    
    /* Text Area */
    @FXML
    private TextArea summaryTA;
    
    /* Handles the close Button */
	@FXML
	public void handleCloseB(ActionEvent event) throws IOException {
		Platform.exit();
	}	
	
	/* Handles the mainMenuB Button */
	@FXML
	public void handleMainMenuB(ActionEvent event) throws IOException {
		Parent scene4 = FXMLLoader.load(getClass().getResource("/view/Menu.fxml"));
		Scene scene4Scene = new Scene(scene4);
		Stage scene4Window = (Stage) ((Node) event.getSource()).getScene().getWindow();
		scene4Window.setScene(scene4Scene);
		scene4Window.show();
	}

	/* handles handleSummaryB */
	@FXML
	public void handleSummaryB(ActionEvent event) throws IOException {
		String summary;
		double totalCost;
		String newDeparture,newReturn;
	
		newDeparture=departure.substring(5) +"-" + departure.substring(0,4);
		newReturn= returning.substring(5) + "-" + returning.substring(0,4);
		totalCost= (days*getCost(hotel))+getCost(flight);
		summaryTA.setVisible(true);
		summary= "Trip Duration: " + days + " day(s)\n" +
				 "Departure Date: " +newDeparture + "\n"+
				 "Return Date: " + newReturn + "\n"+
				 "Destination City: " +city +"\n"+
		         "Hotel: " +hotel + " per night\n" + 
				 "Flight: " +flight + " round trip\n" +
		         "Activities: ";
		if (activities.isEmpty()==true){
			summary+="None\n";
		}else{
			summary+="\n";
			for(String arrayListItems:activities){
				summary+=arrayListItems+"\n";
				totalCost+=getCost(arrayListItems);
			}
		}
		summaryTA.setText(summary + "Total cost of Vacation: $" + new DecimalFormat("#.##").format(totalCost));
		
	}
	
	public void initialize(URL arg0, ResourceBundle arg1) {

	}
	
	/* method to obtain city,hotel,flight,activities,days,departure and return dates from Scene4Controller */
    public void transferMessage(String userCity, String userHotel, String userFlight, ArrayList<String> userActivities,String userDepartureDate,String userReturnDate,int userVacationDays){
    	activities= new ArrayList();
    	
    	city=userCity;
        hotel=userHotel;
        flight=userFlight;
        activities=userActivities;
        days=userVacationDays;
        departure=userDepartureDate;
        returning=userReturnDate;
    }
    
    /* method to obtain the cost($) from a string */
    public double getCost(String sentence){
        double cost;
        String amount;
    	String delimeter;
    	String[] tokens;
    	
    	delimeter="[,]";
    	tokens = sentence.split(delimeter);
    	amount=tokens[1];  
    	cost= Double.parseDouble(amount.substring(1));
    	return cost ;
    }

}
