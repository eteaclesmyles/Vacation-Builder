package controller;

import java.io.IOException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import model.SnowyVacation;

public class SnowScreen4Controller 
{
	@FXML
	AnchorPane mainPane = new AnchorPane();
	
	
	@FXML
	public void selectSkii(ActionEvent event)
	{
		SnowyVacation.hmActivities.put("Skiing Rentals", 60);
		
	}
	
	@FXML
	public void selectSnowboard(ActionEvent event)
	{
		SnowyVacation.hmActivities.put("Snowboarding Rentals", 60);
		
	}
	
	@FXML
	public void selectFishing(ActionEvent event)
	{
		SnowyVacation.hmActivities.put("Fly Fishing Lessons", 150);
		
	}
	
	@FXML
	public void selectGlacierHike(ActionEvent event)
	{
		SnowyVacation.hmActivities.put("Guided Glacier Hike", 169);
		
	}
	
	@FXML
	public void selectOffRoad(ActionEvent event)
	{
		SnowyVacation.hmActivities.put("Extreme Off-Road Adventure", 205);
		
	}
	
	@FXML
	public void selectYoga(ActionEvent event)
	{
		SnowyVacation.hmActivities.put("Yoga in the Wild", 99);
		
	}
	
	@FXML
	public void selectGrizzly(ActionEvent event)
	{
		SnowyVacation.hmActivities.put("Sundowner Grizzly Excursion", 40);
		
	}
	
	@FXML
	public void selectTrailRide(ActionEvent event)
	{
		SnowyVacation.hmActivities.put("Eric's Ranch Property Trail Ride", 50);
		
	}
	
	@FXML
	public void selectPainting(ActionEvent event)
	{
		SnowyVacation.hmActivities.put("Bob Ross Oil Painting Lessons", 65);
		
	}
	
	@FXML
	public void selectPark(ActionEvent event)
	{
		SnowyVacation.hmActivities.put("Grand Teton National Park Tour", 250);
		
	}
	
	@FXML
	public void goToScreen5(ActionEvent clickNextAE) 
	{
		
		System.out.println(SnowyVacation.hmActivities);
		try 
		{
			mainPane = (AnchorPane)FXMLLoader.load(getClass().getResource("/view/SnowScreen5Final.fxml"));
		} 
		
		catch (IOException e) 
		{
			e.printStackTrace();
		}
		
		Scene scene = new Scene(mainPane);
		Stage stageWindow = (Stage)((Node)clickNextAE.getSource()).getScene().getWindow();
		stageWindow.setScene(scene);
		stageWindow.show();
		
		
	}
	
	
	
	
}
